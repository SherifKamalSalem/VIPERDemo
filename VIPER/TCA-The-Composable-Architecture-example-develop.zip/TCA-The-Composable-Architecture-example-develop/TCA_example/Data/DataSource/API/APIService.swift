//
//  APIService.swift
//  clean_architechture
//
//  Created by phan.duong.ngoc on 2023/03/10.
//

import Foundation

final class API: APIBase {
    static var shared = API()
}
