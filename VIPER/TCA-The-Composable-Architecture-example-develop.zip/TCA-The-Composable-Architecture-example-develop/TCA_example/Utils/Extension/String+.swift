//
//  String+.swift
//  TCA_example
//
//  Created by phan.duong.ngoc on 22/05/2024.
//

import Foundation

extension String {
    static func / (lhs: String, rhs: String) -> String {
        return lhs + "/" + rhs
    }
}
